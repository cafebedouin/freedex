/* @ts-self-types="./ergo_lib_wasm.d.ts" */
import * as wasm from "./ergo_lib_wasm_bg.wasm";
import { __wbg_set_wasm } from "./ergo_lib_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    Address, AddressTypePrefix, BatchMerkleProof, BlockHeader, BlockHeaders, BlockId, BoxId, BoxSelection, BoxValue, ChromePeerDiscoveryScan, CommitmentHint, Constant, ContextExtension, Contract, DataInput, DataInputs, DerivationPath, ErgoBox, ErgoBoxAssetsData, ErgoBoxAssetsDataList, ErgoBoxCandidate, ErgoBoxCandidateBuilder, ErgoBoxCandidates, ErgoBoxes, ErgoStateContext, ErgoTree, ExtPubKey, ExtSecretKey, HintsBag, I64, Input, Inputs, LevelNode, MerkleProof, MinerAddress, Mnemonic, NetworkAddress, NetworkPrefix, NipopowProof, NipopowVerifier, NodeConf, NodeInfo, NonMandatoryRegisterId, Parameters, PeerUrls, PoPowHeader, PreHeader, Propositions, ProverResult, ReducedTransaction, SecretKey, SecretKeys, SimpleBoxSelector, Token, TokenAmount, TokenId, Tokens, Transaction, TransactionHintsBag, TxBuilder, TxId, UnsignedBigInt, UnsignedInput, UnsignedInputs, UnsignedTransaction, Wallet, array_as_tuple, base16_decode, extract_hints, get_blocks_header_id_proof_for_tx_id, get_header, get_info, get_nipopow_proof_by_header_id, incremental_peer_discovery_chrome, peer_discovery, validate_tx, verify_signature, verify_tx_input_proof
} from "./ergo_lib_wasm_bg.js";
